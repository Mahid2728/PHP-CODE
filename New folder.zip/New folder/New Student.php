<?php 
include 'header.php'
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<style>
		.sine1{
			width: 100%;
			overflow: hidden;
			padding: 20px 0;
		}
		.contaner2{
			width: 50%;
    		margin: 0 auto;
		}
		.contaner2 h2{
			background: skyblue;
    		padding: 6px;
    		color: white;
		}
		input{
			padding: 5px 20px 5px 5px;
		}
		input[type="submit"]{
			padding: 5px 10px;
    		background: skyblue;
    		border: none;
    		border-radius: 6px;
		}
		form{
			text-align: center;
		}
	</style>
</head>
<body>
<div class="sine1">
	<div class="contaner2">
	<h2>New Student</h2>
	<div>
		<form action="save.php" method="POST">
			<br>Name : <br>
			<input type="text" name="Name" placeholder="Name"><br>
			<br>E-mail: <br>
			<input type="email" name="Email" placeholder="Email"><br>
			<br>Password : <br>
			<input type="password" name="Password" placeholder="Password"><br>
			<br><input type="submit" name="Submit" value="SING UP">
		</form>
		</div>
	</div>
</div>
</body>
</html>