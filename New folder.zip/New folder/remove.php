<?php  
include 'connent.php';
$id=$_GET['id'];
$sql = "DELETE FROM new_folder WHERE id='$id'";

	if (mysqli_query($conn, $sql)) {
	  echo "Record deleted successfully";
	} else {
	  echo "Error deleting record: " . mysqli_error($conn);
	}

header('location: 0.php');
?>