<?php
include 'connent.php';

$Name =$_POST['Name'];
$Email =$_POST['Email'];
$Password =$_POST['Password'];


$sql = "INSERT INTO new_folder (Name, Email , Password)
          VALUES ('$Name', '$Email', '$Password')";

          if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }

header('location: 0.php');
?>