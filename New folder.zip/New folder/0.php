<?php 
include 'header.php';
include 'connent.php';
$sql = "SELECT * FROM new_folder";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 70%;
  margin: 0 auto;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
h1 {
  text-align: center;
  color: skyblue;
  margin: 20px 0;
}
.up{
  text-decoration: none;
    background-color: green;
    padding: 5px 10px;
    color: white;
    border: 2px solid black;
    border-radius: 10px;
}
.up:hover{
  background-color: darkgreen;
}
.re{
  text-decoration: none;
    background-color: red;
    padding: 5px 10px;
    color: white;
    border: 2px solid black;
    border-radius: 10px;
}
.re:hover{
  background-color: darkred;
}
</style>
</head>
<body>
  <h1>Students</h1>
  <table>
  <tr>
     <th>List No.</th>
     <th>Name</th>
     <th>Email</th>
     <th>Edit</th>
     </tr>
     <?php
     $No=1;
      while($row = mysqli_fetch_assoc($result)) {
      ?>
<tr>
  <td><?php echo $No++; ?></td>
  <td><?php echo $row['Name'] ?></td>
  <td><?php echo $row['Email'] ?></td>
  <td>
    <a href="update.php?id=<?php echo $row['id'] ?>" class="up">Update</a>
    <a href="remove.php?id=<?php echo $row['id'] ?>" class="re">Remove</a>
  </td>
</tr>
  <?php
  }
  ?>
</table>
</body>
</html>