<?php
include 'connent.php';

$id =$_POST['id'];
$Name =$_POST['Name'];
$Email =$_POST['Email'];
$Password =$_POST['Password'];


$sql = "UPDATE new_folder SET Name='$Name',Email='$Email',Password='$Password' WHERE id='$id' ";

    if (mysqli_query($conn, $sql)) {
      echo "Record updated successfully";
    } else {
      echo "Error updating record: " . mysqli_error($conn);
    }

header('location: 0.php');
?>