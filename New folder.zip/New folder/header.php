<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>CRUD</title>
	<link rel="stylesheet" type="text/css" href="cs.css">
</head>
<body>
<div class="header">
	<div class="contaner">
	<div class="head-left">
	<ul>
		<li><a href="0.php" style="color: black;">School</a></li>
		<li><a href="0.php">Students</a></li>
		<li><a href="New Student.php">New Student</a></li>
	</ul>
	</div>
	<div class="head-right">
		<input type="text" name="" placeholder="Search">	<span>Search</span>
	</div>
	</div>
</div>
</body>
</html>